// src/services/mockAPI.js
export const mockUsers = [
    { id: 1, name: "Alice", email: "alice@example.com", roles: ["Admin"], status: "Active" },
    { id: 2, name: "Bob", email: "bob@example.com", roles: ["Editor"], status: "Inactive" },
  ];
  
  export const mockRoles = [
    { id: 1, name: "Admin", permissions: ["Read", "Write", "Delete"] },
    { id: 2, name: "Editor", permissions: ["Read", "Write"] },
  ];
  
  export const fetchUsers = () => Promise.resolve(mockUsers);
  export const fetchRoles = () => Promise.resolve(mockRoles);
  export const addUser = (user) => {
    mockUsers.push(user);
    return Promise.resolve(user);
  };
  export const addRole = (role) => {
    mockRoles.push(role);
    return Promise.resolve(role);
  };
  