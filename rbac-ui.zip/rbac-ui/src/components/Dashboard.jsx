// src/components/Dashboard.js
import React from "react";
import { Link } from "react-router-dom";
import { Container, Typography, Button } from "@mui/material";

const Dashboard = () => {
  return (
    <Container>
      <Typography variant="h4" gutterBottom>Admin Dashboard</Typography>
      <Button component={Link} to="/users" variant="contained" sx={{ margin: 1 }}>
        Manage Users
      </Button>
      <Button component={Link} to="/roles" variant="contained" sx={{ margin: 1 }}>
        Manage Roles
      </Button>
      <Button component={Link} to="/permissions" variant="contained" sx={{ margin: 1 }}>
        Manage Permissions
      </Button>
    </Container>
  );
};

export default Dashboard;
