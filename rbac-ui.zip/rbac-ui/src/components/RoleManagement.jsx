// src/components/RoleManagement.js
import React, { useEffect, useState } from "react";
import { fetchRoles, addRole } from "../services/mockAPI";
import { Table, TableHead, TableRow, TableCell, TableBody, Button, TextField, Dialog } from "@mui/material";

const RoleManagement = () => {
  const [roles, setRoles] = useState([]);
  const [open, setOpen] = useState(false);
  const [newRole, setNewRole] = useState({ name: "", permissions: [] });

  useEffect(() => {
    fetchRoles().then(setRoles);
  }, []);

  const handleAddRole = () => {
    addRole({ ...newRole, id: roles.length + 1 });
    setRoles([...roles, newRole]);
    setOpen(false);
  };

  return (
    <div>
      <Button variant="contained" onClick={() => setOpen(true)}>
        Add Role
      </Button>
      <Table>
        <TableHead>
          <TableRow>
            <TableCell>Role Name</TableCell>
            <TableCell>Permissions</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {roles.map((role) => (
            <TableRow key={role.id}>
              <TableCell>{role.name}</TableCell>
              <TableCell>{role.permissions.join(", ")}</TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>

      <Dialog open={open} onClose={() => setOpen(false)}>
        <div style={{ padding: "20px" }}>
          <TextField
            label="Role Name"
            fullWidth
            value={newRole.name}
            onChange={(e) => setNewRole({ ...newRole, name: e.target.value })}
          />
          <Button onClick={handleAddRole} variant="contained" style={{ marginTop: "20px" }}>
            Add Role
          </Button>
        </div>
      </Dialog>
    </div>
  );
};

export default RoleManagement;
